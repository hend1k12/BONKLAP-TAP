class BonklapGame {
    constructor() {
        this.gameData = {
            levels: [
                {"name": "Newbie", "requirement": 0, "multiplier": 1, "color": "#FFE8B0"},
                {"name": "Casual Tapper", "requirement": 100, "multiplier": 1.2, "color": "#EFBF31"},
                {"name": "Bonk Enthusiast", "requirement": 500, "multiplier": 1.5, "color": "#E58525"},
                {"name": "Pro Tapper", "requirement": 1500, "multiplier": 2, "color": "#FFA500"},
                {"name": "Tap Expert", "requirement": 3500, "multiplier": 2.5, "color": "#FF8C00"},
                {"name": "Combo Master", "requirement": 7500, "multiplier": 3, "color": "#FF7F50"},
                {"name": "Tap Legend", "requirement": 15000, "multiplier": 4, "color": "#FF6347"},
                {"name": "BONKLAP God", "requirement": 30000, "multiplier": 5, "color": "#FF4500"}
            ],
            achievements: [
                {"id": "first_bonk", "name": "First BONK! 🎯", "description": "Make your first bonk", "requirement": 1, "reward": 10},
                {"id": "hundred_bonks", "name": "Century Club 💯", "description": "Reach 100 bonks", "requirement": 100, "reward": 100},
                {"id": "combo_starter", "name": "Combo King 🔥", "description": "Get a 10x combo", "requirement": "combo_10", "reward": 200},
                {"id": "thousand_bonks", "name": "Bonk Master 👑", "description": "Reach 1000 bonks", "requirement": 1000, "reward": 500},
                {"id": "speed_demon", "name": "Speed Demon ⚡", "description": "Tap 20 times in 5 seconds", "requirement": "speed_20", "reward": 300}
            ]
        };

        this.gameState = {
            playerName: '',
            score: 0,
            totalTaps: 0,
            currentLevel: 0,
            combo: 0,
            bestCombo: 0,
            comboTimer: null,
            speedTaps: [],
            unlockedAchievements: [],
            leaderboard: []
        };

        this.elements = {};
        this.initializeElements();
        this.initializeEventListeners();
        this.loadGameState();
        this.loadLeaderboard();
        this.updateLeaderboard();
    }

    initializeElements() {
        this.elements = {
            registrationScreen: document.getElementById('registration-screen'),
            gameScreen: document.getElementById('game-screen'),
            playerNameInput: document.getElementById('player-name'),
            startButton: document.getElementById('start-game'),
            displayName: document.getElementById('display-name'),
            score: document.getElementById('score'),
            currentLevel: document.getElementById('current-level'),
            multiplier: document.getElementById('multiplier'),
            progressFill: document.getElementById('progress-fill'),
            progressCurrent: document.getElementById('progress-current'),
            progressNext: document.getElementById('progress-next'),
            dogImage: document.getElementById('dog-image'),
            bonkText: document.getElementById('bonk-text'),
            woodenBat: document.getElementById('wooden-bat'),
            floatingPoints: document.getElementById('floating-points'),
            totalTaps: document.getElementById('total-taps'),
            currentCombo: document.getElementById('current-combo'),
            bestCombo: document.getElementById('best-combo'),
            leaderboard: document.getElementById('leaderboard'),
            achievementNotifications: document.getElementById('achievement-notifications')
        };
    }

    initializeEventListeners() {
        // Registration form
        if (this.elements.startButton) {
            this.elements.startButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.startGame();
            });
        }

        if (this.elements.playerNameInput) {
            this.elements.playerNameInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.startGame();
                }
            });

            this.elements.playerNameInput.addEventListener('input', (e) => {
                const name = e.target.value.trim();
                if (this.elements.startButton) {
                    this.elements.startButton.disabled = name.length === 0;
                }
            });
        }

        // Dog clicking
        if (this.elements.dogImage) {
            this.elements.dogImage.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleDogClick(e);
            });

            this.elements.dogImage.addEventListener('touchstart', (e) => {
                e.preventDefault();
                this.handleDogClick(e.touches[0] || e);
            }, { passive: false });
        }

        // Prevent zoom on double tap
        document.addEventListener('touchstart', (e) => {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        }, { passive: false });

        let lastTouchEnd = 0;
        document.addEventListener('touchend', (e) => {
            const now = new Date().getTime();
            if (now - lastTouchEnd <= 300) {
                e.preventDefault();
            }
            lastTouchEnd = now;
        }, { passive: false });
    }

    startGame() {
        if (!this.elements.playerNameInput || !this.elements.startButton) {
            console.error('Required elements not found');
            return;
        }

        const name = this.elements.playerNameInput.value.trim();
        
        if (name.length === 0) {
            alert('Please enter your name!');
            return;
        }

        console.log('Starting game with name:', name);
        
        this.gameState.playerName = name;
        
        if (this.elements.displayName) {
            this.elements.displayName.textContent = name;
        }
        
        // Switch screens
        if (this.elements.registrationScreen && this.elements.gameScreen) {
            this.elements.registrationScreen.classList.add('hidden');
            this.elements.gameScreen.classList.remove('hidden');
        }
        
        this.updateDisplay();
        this.saveGameState();
    }

    handleDogClick(e) {
        // Prevent multiple rapid clicks from causing issues
        if (this.elements.dogImage && this.elements.dogImage.classList.contains('bonk-animate')) return;

        console.log('Dog clicked!');

        // Add speed tap for achievement tracking
        const now = Date.now();
        this.gameState.speedTaps.push(now);
        this.gameState.speedTaps = this.gameState.speedTaps.filter(tap => now - tap < 5000);

        // Calculate points
        const currentLevel = this.gameData.levels[this.gameState.currentLevel];
        const basePoints = 1;
        const comboMultiplier = Math.min(1 + (this.gameState.combo * 0.1), 3);
        const points = Math.floor(basePoints * currentLevel.multiplier * comboMultiplier);

        // Update game state
        this.gameState.score += points;
        this.gameState.totalTaps++;
        this.gameState.combo++;
        
        if (this.gameState.combo > this.gameState.bestCombo) {
            this.gameState.bestCombo = this.gameState.combo;
        }

        // Reset combo timer
        if (this.gameState.comboTimer) {
            clearTimeout(this.gameState.comboTimer);
        }
        this.gameState.comboTimer = setTimeout(() => {
            this.gameState.combo = 0;
            this.updateDisplay();
        }, 2000);

        // Trigger animations
        this.triggerBonkAnimation();
        this.triggerBatAnimation();
        this.showFloatingPoints(points, e);
        this.addScreenShake();

        // Vibration for mobile
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }

        // Update level progression
        this.checkLevelUp();
        
        // Check achievements
        this.checkAchievements();
        
        // Update display
        this.updateDisplay();
        this.saveGameState();
    }

    triggerBonkAnimation() {
        if (!this.elements.dogImage || !this.elements.bonkText) return;

        this.elements.dogImage.classList.add('bonk-animate');
        this.elements.bonkText.classList.add('bonk-show');
        
        setTimeout(() => {
            if (this.elements.dogImage) this.elements.dogImage.classList.remove('bonk-animate');
            if (this.elements.bonkText) this.elements.bonkText.classList.remove('bonk-show');
        }, 600);
    }

    triggerBatAnimation() {
        if (!this.elements.woodenBat) return;

        this.elements.woodenBat.classList.add('bat-swing');
        
        setTimeout(() => {
            if (this.elements.woodenBat) this.elements.woodenBat.classList.remove('bat-swing');
        }, 400);
    }

    showFloatingPoints(points, event) {
        if (!this.elements.floatingPoints || !this.elements.dogImage) return;

        const pointElement = document.createElement('div');
        pointElement.className = 'point-float';
        pointElement.textContent = `+${points}`;
        
        // Position relative to click/touch
        const rect = this.elements.dogImage.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        let clickX = centerX;
        let clickY = centerY;
        
        if (event.clientX !== undefined && event.clientY !== undefined) {
            clickX = event.clientX;
            clickY = event.clientY;
        }
        
        pointElement.style.left = (clickX - centerX + Math.random() * 60 - 30) + 'px';
        pointElement.style.top = (clickY - centerY + Math.random() * 40 - 20) + 'px';
        
        this.elements.floatingPoints.appendChild(pointElement);
        
        setTimeout(() => {
            if (pointElement.parentNode) {
                pointElement.parentNode.removeChild(pointElement);
            }
        }, 1000);
    }

    addScreenShake() {
        document.body.style.animation = 'none';
        document.body.offsetHeight; // Trigger reflow
        document.body.style.animation = 'screenShake 0.2s ease-in-out';
        
        setTimeout(() => {
            document.body.style.animation = '';
        }, 200);
    }

    checkLevelUp() {
        const currentLevel = this.gameState.currentLevel;
        const nextLevel = currentLevel + 1;
        
        if (nextLevel < this.gameData.levels.length) {
            const nextLevelData = this.gameData.levels[nextLevel];
            if (this.gameState.totalTaps >= nextLevelData.requirement) {
                this.gameState.currentLevel = nextLevel;
                this.showAchievement(`Level Up! 🎉`, `You are now a ${nextLevelData.name}!`);
            }
        }
    }

    checkAchievements() {
        this.gameData.achievements.forEach(achievement => {
            if (this.gameState.unlockedAchievements.includes(achievement.id)) return;
            
            let unlocked = false;
            
            switch (achievement.id) {
                case 'first_bonk':
                    unlocked = this.gameState.totalTaps >= 1;
                    break;
                case 'hundred_bonks':
                    unlocked = this.gameState.totalTaps >= 100;
                    break;
                case 'thousand_bonks':
                    unlocked = this.gameState.totalTaps >= 1000;
                    break;
                case 'combo_starter':
                    unlocked = this.gameState.bestCombo >= 10;
                    break;
                case 'speed_demon':
                    unlocked = this.gameState.speedTaps.length >= 20;
                    break;
            }
            
            if (unlocked) {
                this.gameState.unlockedAchievements.push(achievement.id);
                this.gameState.score += achievement.reward;
                this.showAchievement(achievement.name, `${achievement.description} (+${achievement.reward} points)`);
            }
        });
    }

    showAchievement(title, description) {
        if (!this.elements.achievementNotifications) return;

        const achievementEl = document.createElement('div');
        achievementEl.className = 'achievement';
        achievementEl.innerHTML = `
            <div class="achievement-title">${title}</div>
            <div class="achievement-description">${description}</div>
        `;
        
        this.elements.achievementNotifications.appendChild(achievementEl);
        
        setTimeout(() => {
            if (achievementEl.parentNode) {
                achievementEl.parentNode.removeChild(achievementEl);
            }
        }, 5000);
    }

    updateDisplay() {
        // Score with animation
        if (this.elements.score) {
            this.elements.score.textContent = this.gameState.score.toLocaleString();
            this.elements.score.classList.add('score-animate');
            setTimeout(() => {
                if (this.elements.score) this.elements.score.classList.remove('score-animate');
            }, 500);
        }
        
        // Level info
        const currentLevel = this.gameData.levels[this.gameState.currentLevel];
        if (this.elements.currentLevel) {
            this.elements.currentLevel.textContent = currentLevel.name;
        }
        if (this.elements.multiplier) {
            this.elements.multiplier.textContent = currentLevel.multiplier;
        }
        
        // Progress bar
        const nextLevelIndex = this.gameState.currentLevel + 1;
        if (nextLevelIndex < this.gameData.levels.length) {
            const nextLevel = this.gameData.levels[nextLevelIndex];
            const progress = Math.min((this.gameState.totalTaps - currentLevel.requirement) / 
                                    (nextLevel.requirement - currentLevel.requirement) * 100, 100);
            
            if (this.elements.progressFill) {
                this.elements.progressFill.style.width = `${Math.max(0, progress)}%`;
            }
            if (this.elements.progressCurrent) {
                this.elements.progressCurrent.textContent = this.gameState.totalTaps;
            }
            if (this.elements.progressNext) {
                this.elements.progressNext.textContent = nextLevel.requirement;
            }
        } else {
            if (this.elements.progressFill) this.elements.progressFill.style.width = '100%';
            if (this.elements.progressCurrent) this.elements.progressCurrent.textContent = this.gameState.totalTaps;
            if (this.elements.progressNext) this.elements.progressNext.textContent = 'MAX';
        }
        
        // Stats
        if (this.elements.totalTaps) {
            this.elements.totalTaps.textContent = this.gameState.totalTaps.toLocaleString();
        }
        if (this.elements.currentCombo) {
            this.elements.currentCombo.textContent = this.gameState.combo;
        }
        if (this.elements.bestCombo) {
            this.elements.bestCombo.textContent = this.gameState.bestCombo;
        }
    }

    updateLeaderboard() {
        if (!this.elements.leaderboard) return;

        this.elements.leaderboard.innerHTML = '';
        
        if (this.gameState.leaderboard.length === 0) {
            this.elements.leaderboard.innerHTML = '<div style="text-align: center; color: #8B4513; font-style: italic;">No bonkers yet!</div>';
            return;
        }
        
        this.gameState.leaderboard.slice(0, 10).forEach((entry, index) => {
            const entryEl = document.createElement('div');
            entryEl.className = 'leaderboard-entry';
            
            const medal = index < 3 ? ['🥇', '🥈', '🥉'][index] : '';
            
            entryEl.innerHTML = `
                <div class="leaderboard-rank">${medal} #${index + 1}</div>
                <div class="leaderboard-name">${entry.name}</div>
                <div class="leaderboard-score">${entry.score.toLocaleString()}</div>
            `;
            
            this.elements.leaderboard.appendChild(entryEl);
        });
    }

    saveGameState() {
        const saveData = {
            playerName: this.gameState.playerName,
            score: this.gameState.score,
            totalTaps: this.gameState.totalTaps,
            currentLevel: this.gameState.currentLevel,
            bestCombo: this.gameState.bestCombo,
            unlockedAchievements: this.gameState.unlockedAchievements
        };
        console.log('Saving game state:', saveData);
    }

    loadGameState() {
        // For this demo, we'll start fresh each time
        console.log('Game state loaded');
    }

    updateLeaderboardEntry() {
        if (!this.gameState.playerName || this.gameState.score === 0) return;
        
        // Find existing entry or create new one
        let existingIndex = this.gameState.leaderboard.findIndex(
            entry => entry.name === this.gameState.playerName
        );
        
        if (existingIndex >= 0) {
            this.gameState.leaderboard[existingIndex].score = Math.max(
                this.gameState.leaderboard[existingIndex].score,
                this.gameState.score
            );
        } else {
            this.gameState.leaderboard.push({
                name: this.gameState.playerName,
                score: this.gameState.score
            });
        }
        
        // Sort and limit to top 10
        this.gameState.leaderboard.sort((a, b) => b.score - a.score);
        this.gameState.leaderboard = this.gameState.leaderboard.slice(0, 10);
        
        this.updateLeaderboard();
    }

    loadLeaderboard() {
        // Initialize with empty leaderboard
        this.gameState.leaderboard = [];
    }
}

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing game...');
    window.bonklapGame = new BonklapGame();
    console.log('Game initialized:', window.bonklapGame);
});