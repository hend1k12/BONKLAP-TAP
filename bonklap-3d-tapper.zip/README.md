# BONKLAP - Tap to Earn Game 🐕💰

Welcome to **BONKLAP**, a fun tap-to-earn game where players tap the BONK dog to earn $BONKLAP tokens and prepare for the upcoming airdrop!

## 🚀 Features

- **Tap-to-Earn Gameplay**: Tap the BONK dog and earn $BONKLAP points
- **AIRDROP SOON**: Prominent banner showing upcoming airdrop
- **Level System**: Progress through 8 levels from Newbie to BONKLAP Legend
- **Combo System**: Fast taps give bonus points and higher multipliers
- **Leaderboard**: Compete with other players for the top spot
- **Simple Registration**: Just enter a username to start playing
- **Mobile Optimized**: Works perfectly on phones and tablets
- **Haptic Feedback**: Vibration on mobile devices for better experience
- **Local Storage**: Your progress is automatically saved

## 🎮 How to Play

1. **Login**: Click the "Login" button and enter your username
2. **Tap**: Click or tap the BONK dog to earn points
3. **Build Combos**: Tap quickly to build combo multipliers
4. **Level Up**: Reach score thresholds to unlock new levels
5. **Compete**: Check the leaderboard to see your ranking
6. **Earn**: Keep playing to earn more $BONKLAP for the airdrop!

## 📁 File Structure

```
bonklap-site/
├── index.html      # Main HTML file
├── styles.css      # CSS styling (yellow BONK theme)
├── script.js       # JavaScript game logic
└── README.md       # This file
```

## 🛠️ Installation & Setup

### Option 1: GitHub Pages (Recommended)

1. **Create GitHub Repository**
   - Go to [github.com](https://github.com) and create a new repository
   - Name it `bonklap-site` or similar
   - Make it public

2. **Upload Files**
   - Upload all files (`index.html`, `styles.css`, `script.js`, `README.md`)
   - Commit the changes

3. **Enable GitHub Pages**
   - Go to repository Settings
   - Navigate to Pages section
   - Select "Deploy from branch" → "main" → "/ (root)"
   - Save settings

4. **Access Your Site**
   - Your site will be available at: `https://username.github.io/bonklap-site/`
   - Share this URL with players!

### Option 2: Local Testing

1. **Download Files**
   - Save all files in the same folder
   - Make sure file names match exactly

2. **Open Locally**
   - Double-click `index.html`
   - Game will open in your browser

## 🎨 Design Features

- **Yellow Theme**: Inspired by BONK meme coin colors
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Smooth Animations**: Bat swing animation when tapping
- **Modern UI**: Clean, professional interface
- **Accessibility**: Keyboard support (spacebar to tap)

## 🏆 Game Mechanics

### Level System
- Level 1: Newbie Bonker (0 points)
- Level 2: Casual Tapper (100 points) 
- Level 3: Bonk Enthusiast (250 points)
- Level 4: Dedicated Tapster (500 points)
- Level 5: Bonk Master (1,000 points)
- Level 6: Tap Legend (2,000 points)
- Level 7: BONKLAP Pro (5,000 points)
- Level 8: BONKLAP Legend (10,000 points)

### Combo System
- **Regular Tap**: +1 point
- **Small Combo** (3-5 fast taps): +2 points
- **Big Combo** (6+ fast taps): +3 points

### Statistics Tracked
- Total Score ($BONKLAP earned)
- Total Taps
- Taps per Second
- Best Combo Streak
- Current Level

## 🔧 Technical Details

- **Frontend**: Pure HTML5, CSS3, JavaScript (ES6+)
- **Storage**: Local Storage for user data persistence
- **Mobile**: Touch events and haptic feedback support
- **Performance**: 60 FPS animations, optimized for mobile
- **Browser Support**: All modern browsers

## 🚀 Deployment Options

### Free Hosting Options
1. **GitHub Pages** (recommended for beginners)
2. **Netlify** - Drag and drop deployment
3. **Vercel** - Fast deployment with GitHub integration
4. **Surge.sh** - Simple static site hosting

### Custom Domain
- Most hosting platforms allow custom domain setup
- Perfect for branding your BONKLAP game

## 📱 Telegram Mini App Integration

This game is ready to be integrated as a Telegram Mini App:

1. Create a Telegram bot using @BotFather
2. Use `/newapp` command to create Mini App
3. Set your deployed URL as the Mini App URL
4. Players can access directly through Telegram

## 🎯 Future Enhancements

- **Backend Integration**: Global leaderboard with database
- **Web3 Integration**: Connect crypto wallets
- **NFT Support**: Special BONK dog variants
- **Multiplayer Features**: Real-time competitions
- **Sound Effects**: Audio feedback for taps
- **Achievement System**: Unlock rewards for milestones

## 🐛 Troubleshooting

### Common Issues

**Game not loading?**
- Check that all files are in the same folder
- Ensure file names match exactly (case-sensitive)
- Try opening in a different browser

**Taps not registering?**
- Make sure JavaScript is enabled
- Try refreshing the page
- Check browser console for errors

**Progress not saving?**
- Ensure local storage is enabled
- Don't use private/incognito mode
- Check browser settings for storage permissions

## 📄 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to contribute to this project by:
- Reporting bugs
- Suggesting new features
- Submitting pull requests
- Sharing feedback

---

**Have fun tapping and earning $BONKLAP! 🚀🐕💎**

*Remember: This is a fun game for the community. Actual token distribution depends on the project's tokenomics and airdrop terms.*