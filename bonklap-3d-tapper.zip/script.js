// BONKLAP Game JavaScript

class BonklapGame {
    constructor() {
        this.score = 0;
        this.totalTaps = 0;
        this.level = 1;
        this.tapCount = 0;
        this.comboCount = 0;
        this.bestCombo = 0;
        this.lastTapTime = 0;
        this.tapsPerSecond = 0;
        this.tapTimes = [];
        this.currentUser = localStorage.getItem('bonklapUser') || 'Guest';
        
        this.initializeGame();
        this.setupEventListeners();
        this.loadUserData();
        this.updateDisplay();
        this.startTapCounter();
    }

    initializeGame() {
        // Get DOM elements
        this.bonkDog = document.getElementById('bonkDog');
        this.scoreNumber = document.getElementById('scoreNumber');
        this.userLevel = document.getElementById('userLevel');
        this.progressFill = document.getElementById('progressFill');
        this.totalTapsEl = document.getElementById('totalTaps');
        this.tapsPerSecondEl = document.getElementById('tapsPerSecond');
        this.comboCountEl = document.getElementById('comboCount');
        this.tapEffect = document.getElementById('tapEffect');
        this.userName = document.getElementById('userName');
        this.loginBtn = document.getElementById('loginBtn');
        this.loginModal = document.getElementById('loginModal');
        this.usernameInput = document.getElementById('usernameInput');
        this.startGameBtn = document.getElementById('startGameBtn');
        this.closeModal = document.querySelector('.close');
        this.bat = document.getElementById('bat');

        // Update username display
        this.userName.textContent = this.currentUser;
        if (this.currentUser !== 'Guest') {
            this.loginBtn.textContent = 'Change User';
        }
    }

    setupEventListeners() {
        // Bonk dog tap event
        this.bonkDog.addEventListener('click', (e) => this.handleTap(e));
        
        // Touch events for mobile
        this.bonkDog.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.handleTap(e);
        });

        // Login modal events
        this.loginBtn.addEventListener('click', () => this.showLoginModal());
        this.closeModal.addEventListener('click', () => this.hideLoginModal());
        this.startGameBtn.addEventListener('click', () => this.handleLogin());
        
        // Username input enter key
        this.usernameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleLogin();
            }
        });

        // Close modal on outside click
        window.addEventListener('click', (e) => {
            if (e.target === this.loginModal) {
                this.hideLoginModal();
            }
        });
    }

    handleTap(e) {
        const currentTime = Date.now();
        
        // Add to tap times array for taps per second calculation
        this.tapTimes.push(currentTime);
        this.tapTimes = this.tapTimes.filter(time => currentTime - time < 1000);
        
        // Update scores
        this.score++;
        this.totalTaps++;
        this.tapCount++;
        
        // Check for combo
        if (currentTime - this.lastTapTime < 500) {
            this.comboCount++;
            if (this.comboCount > this.bestCombo) {
                this.bestCombo = this.comboCount;
            }
        } else {
            this.comboCount = 1;
        }
        
        this.lastTapTime = currentTime;
        
        // Update level
        this.updateLevel();
        
        // Visual effects
        this.showTapEffect();
        this.animateBonkDog();
        this.showBatAnimation();
        
        // Update display
        this.updateDisplay();
        this.saveUserData();
        
        // Haptic feedback for mobile
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }
    }

    showTapEffect() {
        let points = 1;
        if (this.comboCount > 5) points = 3;
        else if (this.comboCount > 2) points = 2;
        
        this.tapEffect.textContent = `+${points}`;
        this.tapEffect.classList.add('show');
        
        setTimeout(() => {
            this.tapEffect.classList.remove('show');
        }, 800);
        
        // Add extra points for combo
        if (points > 1) {
            this.score += points - 1;
        }
    }

    animateBonkDog() {
        this.bonkDog.classList.add('bonking');
        setTimeout(() => {
            this.bonkDog.classList.remove('bonking');
        }, 300);
    }

    showBatAnimation() {
        this.bonkDog.classList.add('hitting');
        setTimeout(() => {
            this.bonkDog.classList.remove('hitting');
        }, 300);
    }

    updateLevel() {
        const levelThresholds = [0, 100, 250, 500, 1000, 2000, 5000, 10000];
        let newLevel = 1;
        
        for (let i = 0; i < levelThresholds.length; i++) {
            if (this.score >= levelThresholds[i]) {
                newLevel = i + 1;
            }
        }
        
        if (newLevel !== this.level) {
            this.level = newLevel;
            this.showLevelUp();
        }
        
        // Update progress bar
        const currentThreshold = levelThresholds[this.level - 1] || 0;
        const nextThreshold = levelThresholds[this.level] || levelThresholds[levelThresholds.length - 1];
        const progress = ((this.score - currentThreshold) / (nextThreshold - currentThreshold)) * 100;
        this.progressFill.style.width = Math.min(progress, 100) + '%';
    }

    showLevelUp() {
        const levelUpEffect = document.createElement('div');
        levelUpEffect.className = 'combo-effect show';
        levelUpEffect.textContent = `LEVEL UP! ${this.level}`;
        levelUpEffect.style.color = '#FF6B35';
        document.querySelector('.bonk-container').appendChild(levelUpEffect);
        
        setTimeout(() => {
            levelUpEffect.remove();
        }, 1000);
    }

    updateDisplay() {
        this.scoreNumber.textContent = this.score.toLocaleString();
        this.userLevel.textContent = this.level;
        this.totalTapsEl.textContent = this.totalTaps.toLocaleString();
        this.comboCountEl.textContent = this.bestCombo;
    }

    startTapCounter() {
        setInterval(() => {
            this.tapsPerSecond = this.tapTimes.length;
            this.tapsPerSecondEl.textContent = this.tapsPerSecond;
        }, 100);
    }

    showLoginModal() {
        this.loginModal.style.display = 'block';
        this.usernameInput.focus();
    }

    hideLoginModal() {
        this.loginModal.style.display = 'none';
        this.usernameInput.value = '';
    }

    handleLogin() {
        const username = this.usernameInput.value.trim();
        if (username && username.length >= 2) {
            this.currentUser = username;
            this.userName.textContent = username;
            this.loginBtn.textContent = 'Change User';
            localStorage.setItem('bonklapUser', username);
            this.hideLoginModal();
            this.saveUserData();
            this.updateLeaderboard();
        } else {
            alert('Please enter a username with at least 2 characters!');
        }
    }

    saveUserData() {
        const userData = {
            username: this.currentUser,
            score: this.score,
            totalTaps: this.totalTaps,
            level: this.level,
            bestCombo: this.bestCombo,
            timestamp: Date.now()
        };
        localStorage.setItem(`bonklap_${this.currentUser}`, JSON.stringify(userData));
    }

    loadUserData() {
        if (this.currentUser !== 'Guest') {
            const userData = localStorage.getItem(`bonklap_${this.currentUser}`);
            if (userData) {
                const data = JSON.parse(userData);
                this.score = data.score || 0;
                this.totalTaps = data.totalTaps || 0;
                this.level = data.level || 1;
                this.bestCombo = data.bestCombo || 0;
            }
        }
    }

    updateLeaderboard() {
        // Get all user data from localStorage
        const leaderboardData = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('bonklap_') && key !== 'bonklapUser') {
                try {
                    const data = JSON.parse(localStorage.getItem(key));
                    if (data.username && data.score) {
                        leaderboardData.push({
                            username: data.username,
                            score: data.score,
                            level: data.level || 1
                        });
                    }
                } catch (e) {
                    console.error('Error parsing user data:', e);
                }
            }
        }

        // Sort by score
        leaderboardData.sort((a, b) => b.score - a.score);
        
        // Update leaderboard display
        const leaderboardList = document.getElementById('leaderboardList');
        if (leaderboardData.length > 0) {
            leaderboardList.innerHTML = '';
            leaderboardData.slice(0, 10).forEach((player, index) => {
                const item = document.createElement('div');
                item.className = 'leaderboard-item';
                if (player.username === this.currentUser) {
                    item.style.background = 'rgba(229, 133, 37, 0.1)';
                    item.style.fontWeight = 'bold';
                }
                item.innerHTML = `
                    <span class="rank">${index + 1}</span>
                    <span class="name">${player.username} (Lv.${player.level})</span>
                    <span class="score">${player.score.toLocaleString()}</span>
                `;
                leaderboardList.appendChild(item);
            });
        }
    }
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.bonklapGame = new BonklapGame();
    
    // Update leaderboard periodically
    setInterval(() => {
        window.bonklapGame.updateLeaderboard();
    }, 5000);
});

// Add keyboard support
document.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && window.bonklapGame) {
        e.preventDefault();
        const event = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
        });
        window.bonklapGame.bonkDog.dispatchEvent(event);
    }
});

// Prevent context menu on bonk dog
document.addEventListener('contextmenu', (e) => {
    if (e.target.id === 'bonkDog' || e.target.closest('#bonkDog')) {
        e.preventDefault();
    }
});